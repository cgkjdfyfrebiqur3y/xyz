#!/usr/bin/env bash
mkdir /root/hack
mv ./hide /root/hack -r
cd /root
~/hack/maliciuos\ file.bash